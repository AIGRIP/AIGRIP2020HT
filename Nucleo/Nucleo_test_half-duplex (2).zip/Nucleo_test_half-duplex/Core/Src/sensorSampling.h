/*
 * sensorSampling.h
 *
 *  Created on: 27 Nov 2020
 *      Author: AutoBike01
 */

#ifndef SRC_SENSORSAMPLING_H_
#define SRC_SENSORSAMPLING_H_


#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "stm32h7xx_hal.h"
#include "cmsis_os.h"

#include "typedefsGripperNucleo.h"

void readSensors(osMessageQueueId_t opticalSensorQueue, SPI_HandleTypeDef *hspi4, UART_HandleTypeDef *uartDebugHandle);


#endif /* SRC_SENSORSAMPLING_H_ */
