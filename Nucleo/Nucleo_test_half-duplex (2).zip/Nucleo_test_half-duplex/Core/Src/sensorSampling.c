/*
 * senorSampling.c
 *
 *  Created on: 27 Nov 2020
 *      Author: AutoBike01
 */

#include "sensorSampling.h"

#include "PMW3360Drivers.h"


void readSensors(osMessageQueueId_t opticalSensorQueue, SPI_HandleTypeDef *hspi4, UART_HandleTypeDef *uartDebugHandle)
{

	int i;
	// To store the readings from the mouse sensor.
	sensValue mouseSensorPacket[NUMBER_OF_MOUSE_SESNORS];

	memset(&mouseSensorPacket,0,NUMBER_OF_MOUSE_SESNORS*sizeof(sensValue));

	// Devug variables.
	const short buffLength = 60;
	char messageBuffer[buffLength];
	short bufferStringLength;



//	HAL_UART_Transmit(uartDebugHandle,(uint8_t *) "Starting Mouse sensors\r\n", sizeof("Starting Mouse sensors\r\n"), 100);


	// The GPIO ports for the chip select ports for the SPI communication to the mouse sensors.
	GPIO_TypeDef * GPIOPortsForChipSelect[] = {GPIOA,GPIOA,GPIOC,GPIOC,GPIOC,GPIOG};
	uint16_t GPIOPinNumberForChipSelect[] = {GPIO_PIN_1,GPIO_PIN_2,GPIO_PIN_1,GPIO_PIN_4,GPIO_PIN_5,GPIO_PIN_13};

	uint64_t currTick1, currTick2, executionTicks = 0;

//	HAL_UART_Transmit(uartDebugHandle,(uint8_t *) "Debug 0\r\n", sizeof("Debug 0\r\n"), 100);

/*
	startUpMouse( hspi4, GPIOPortsForChipSelect[0],GPIOPinNumberForChipSelect[0],uartDebugHandle );
	startUpMouse( hspi4, GPIOPortsForChipSelect[2],GPIOPinNumberForChipSelect[2],uartDebugHandle );
	startUpMouse( hspi4, GPIOPortsForChipSelect[3],GPIOPinNumberForChipSelect[3],uartDebugHandle );
*/
//	HAL_UART_Transmit(uartDebugHandle,(uint8_t *) "Started Mouse sensors\r\n", sizeof("Started Mouse sensors\r\n"), 100);

	while(1)
	{

		if (osMessageQueueGetSpace(opticalSensorQueue) >= NUMBER_OF_MOUSE_SESNORS*2 )
		{
			currTick1 = osKernelGetTickCount();
			// Read the mouse sensor values. Currently there are only three mouse sensors that are on the gripper.
			readMouseSensor( &mouseSensorPacket[0], hspi4, GPIOPortsForChipSelect[0],GPIOPinNumberForChipSelect[0] );
			//readMouseSensor( &mouseSensorPacket[1], hspi4, GPIOPortsForChipSelect[1],GPIOPinNumberForChipSelect[1] );
			//readMouseSensor( &mouseSensorPacket[2], hspi4, GPIOPortsForChipSelect[2],GPIOPinNumberForChipSelect[2] );
			readMouseSensor( &mouseSensorPacket[3], hspi4, GPIOPortsForChipSelect[3],GPIOPinNumberForChipSelect[3] );
			//readMouseSensor( &mouseSensorPacket[4], hspi4, GPIOPortsForChipSelect[4],GPIOPinNumberForChipSelect[4] );
			readMouseSensor( &mouseSensorPacket[5], hspi4, GPIOPortsForChipSelect[5],GPIOPinNumberForChipSelect[5] );

			currTick2 = osKernelGetTickCount() - currTick1;

			// Send sensorValues to control thread. It only needs the mouse sensor values.
			for( i = 0; i < NUMBER_OF_MOUSE_SESNORS; i++ )
			{
				// Send all mouse sensor magnitude data.
				osMessageQueuePut(opticalSensorQueue, &mouseSensorPacket[i].mouse_D_X, 1, 0U);
				osMessageQueuePut(opticalSensorQueue, &mouseSensorPacket[i].mouse_D_Y, 1, 0U);
			}
		}



		osDelay(100);
		// Is the delay that desides the sample time for the sesnor.
		//osDelay(150);

	}

}


/*
 *   VL6180xDev_t myDev = 0x29; //0x28;
  VL6180x_RangeData_t Range;

  char proximityRange[40];
  //const char Err1Mess[] = "Error init data %d.\n\r";
  //const char Err2Mess[] = "Error in prepare %d.\n\r";
  const char Err3Mess[] = "Error to in reading distance.\n\r";

  int statusErr;

  //startUpMouse(&hspi4);

  uint8_t recData = 0;

  uint16_t IDReg = 0x000;

  ---------

	statusErr = HAL_I2C_Master_Transmit(&hi2c2, myDev,(uint8_t *) &IDReg, 2, 100);

	sprintf(proximityRange,"Error send register adress %d.\n\r", statusErr);
	HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);

	statusErr = HAL_I2C_Master_Receive(&hi2c2, myDev, &recData, 1, 100);

	sprintf(proximityRange,"Error receive register adress %d.\n\r", statusErr);
	HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);

	//VL6180x_RdByte( myDev,  0x000,  &recData);

	sprintf(proximityRange,"Model ID is: %x\n\r", recData);
	HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);

	osKernelLock();

	statusErr = VL6180x_InitData(myDev);

	if(statusErr != 0)
	{
		sprintf(proximityRange,"Error init data %d.\n\r", statusErr);
		HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);
	}


	statusErr = VL6180x_Prepare(myDev);


	if(statusErr != 0)
	{
		sprintf(proximityRange,"Error in prepare %d.\n\r", statusErr);
		HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);
	}

	// Read proximity sensor by polling.
	statusErr = VL6180x_RangePollMeasurement(myDev, &Range);
	osKernelUnlock();


	if(statusErr != 0)
	{
		sprintf(proximityRange,"Error in range %d.\n\r", statusErr);
		HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);
	}

	if(Range.errorStatus == 0)
	{
		sprintf(proximityRange,"The range is %d mm \n\r", (int) Range.range_mm);

		HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);
	}else{

		HAL_UART_Transmit(&huart3,(uint8_t *) Err3Mess, sizeof(Err3Mess), 100);

	}
	//int32_t

	sprintf(proximityRange,"The range is %d mm \n\r", (int) Range.range_mm);

	HAL_UART_Transmit(&huart3,(uint8_t *) proximityRange, sizeof(proximityRange), 100);

	*/
